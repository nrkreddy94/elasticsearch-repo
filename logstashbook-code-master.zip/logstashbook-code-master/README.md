# The Logstash Book Code Repository

Contains the code and configuration examples from [The Logstash
Book](http://www.logstashbook.com).

*Now updated for Logstash v1.4.1.*

## Errata

Email errata [here](mailto:james+lserrata@lovedthanlost.net)

