wget http://d3kbcqa49mib13.cloudfront.net/spark-2.1.0-bin-hadoop2.7.tgz
tar xfvz spark-2.1.0-bin-hadoop2.7.tgz

