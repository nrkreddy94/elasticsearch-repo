brew install pig
brew install apache-spark

