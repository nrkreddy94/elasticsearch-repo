wget http://download.elastic.co/hadoop/elasticsearch-hadoop-5.1.1.zip
unzip elasticsearch-hadoop-5.1.1.zip


