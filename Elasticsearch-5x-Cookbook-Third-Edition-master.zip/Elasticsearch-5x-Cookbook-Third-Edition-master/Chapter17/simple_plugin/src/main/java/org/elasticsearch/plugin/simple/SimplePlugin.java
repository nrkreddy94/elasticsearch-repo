package org.elasticsearch.plugin.simple;


import org.elasticsearch.plugins.Plugin;

public class SimplePlugin extends Plugin {

}
